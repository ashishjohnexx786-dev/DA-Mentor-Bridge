B06 Gate B - Support Tickets. Fresh full retest only if explicitly routed. Determine source grains, model, history, quality and platform controls independently.
