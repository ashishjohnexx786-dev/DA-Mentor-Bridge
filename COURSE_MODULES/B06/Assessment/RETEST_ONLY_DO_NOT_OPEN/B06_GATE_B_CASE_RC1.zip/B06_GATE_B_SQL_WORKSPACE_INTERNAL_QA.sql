-- B06 FINAL GATE B - SUPPORT TICKETS SQL WORKSPACE
SET search_path TO c2b_b06_gate_b;
-- Fresh full retest only when explicitly routed.

-- B1 SOURCE GRAIN / KEYS
-- Infer grain/key for agents, agent_team_changes, tickets, ticket_events,
-- ticket_tags, csat, sla_targets and monthly_team_targets.
-- Prove one fan-out risk with row counts.

-- B2 TRUSTED SLA / RESOLUTION METRICS
-- One row/closed ticket with resolution_days and SLA outcome.
-- Reconcile closed-ticket count and prevent event/tag multiplication.

-- B3 ADVANCED SQL
-- Team/priority analysis using staged CTEs.
-- Add one window/rank and one weekly/monthly LAG/change calculation.

-- B4 HISTORY / QUALITY
-- Detect orphan ticket_events, duplicate ticket-tag business memberships,
-- and duplicate same-effective-date agent team changes.
-- Add at least two additional justified quality checks.

-- B5 MAINTAINABLE HANDOFF
-- Deterministic output + grain comments + independent SLA/CSAT reconciliation.

-- B6 EXECUTION AWARENESS
-- EXPLAIN one selective priority/status/date query; propose a candidate index only if justified.
