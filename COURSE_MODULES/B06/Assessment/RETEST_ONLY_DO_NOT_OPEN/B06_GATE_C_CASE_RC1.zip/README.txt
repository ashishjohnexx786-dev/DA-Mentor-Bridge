B06 Gate C - Subscription Billing. Second fresh full retest only if explicitly routed. Determine grains, SCD, quality, access, refresh and recovery independently.
