-- B06 FINAL GATE C - SUBSCRIPTION BILLING SQL WORKSPACE
SET search_path TO c2b_b06_gate_c;
-- Second fresh full retest only when explicitly routed.

-- C1 SOURCE GRAIN / KEYS
-- Infer grain/key for accounts, account_profile_changes, subscriptions, invoices,
-- invoice_lines, payments, usage_daily and monthly_segment_targets.
-- Prove one fan-out risk with row counts.

-- C2 TRUSTED BILLING / COLLECTION METRICS
-- One row/invoice with invoice value and payment/collection status.
-- Reconcile invoice-line value independently and prevent line/payment multiplication.

-- C3 ADVANCED SQL
-- Segment/month billing analysis using staged CTEs.
-- Add one window/rank and one monthly LAG/change calculation.

-- C4 HISTORY / QUALITY
-- Detect orphan payments and duplicate same-effective-date account profile changes.
-- Add at least two additional justified quality checks.

-- C5 MAINTAINABLE HANDOFF
-- Deterministic output + grain comments + separate invoice/payment reconciliation.

-- C6 EXECUTION AWARENESS
-- EXPLAIN one selective account/status/date query; propose a candidate index only if justified.
