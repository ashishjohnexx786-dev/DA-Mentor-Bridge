-- B06 FINAL GATE A - RETAIL ORDERS SQL WORKSPACE
SET search_path TO c2b_b06_gate_a;
-- Protected independent assessment: lesson/review/tutorial/AI solving closed.

-- A1 SOURCE GRAIN / KEYS
-- Infer grain/key for customers, customer_profile_changes, orders, order_items,
-- order_events, returns, customer_tags and monthly_region_targets.
-- Prove one fan-out risk with row counts.

-- A2 TRUSTED ORDER ECONOMICS
-- One row/order: item net value, shipping fee, return/refund treatment and customer context.
-- Reconcile item-level value independently and prevent shipping_fee multiplication.

-- A3 ADVANCED SQL
-- Completed-order region/channel analysis using staged CTEs.
-- Add one window/rank and one monthly LAG/change calculation.

-- A4 HISTORY / QUALITY
-- Detect orphan order_events and duplicate same-effective-date customer profile changes.
-- Add at least two additional justified quality checks.

-- A5 MAINTAINABLE HANDOFF
-- Deterministic output + explicit grain comments + separate reconciliation query.

-- A6 EXECUTION AWARENESS
-- EXPLAIN one selective customer/date/status query; propose a candidate index only if justified.
