B06 Gate A - Retail Orders. Determine source grain, keys, model, quality controls, platform/access and evidence independently. Expected answers and totals are not included.
