B05 Gate A - Manufacturing Quality. Independent first attempt. Decide platform, access, connection/gateway, refresh, monitoring and governance from requirements. Expected decisions are not provided.
