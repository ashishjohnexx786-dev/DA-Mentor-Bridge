B05 Gate B - Digital Advertising. Fresh full retest only if explicitly routed. No expected architecture is provided.
