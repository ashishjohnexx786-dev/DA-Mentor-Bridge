B05 Gate C - Travel Bookings. Second fresh retest only if explicitly routed. No expected architecture is provided.
