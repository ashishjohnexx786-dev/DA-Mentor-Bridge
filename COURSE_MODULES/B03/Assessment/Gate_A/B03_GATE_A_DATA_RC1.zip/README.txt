B03 GATE A - FLEET MAINTENANCE
Independent modeling assessment.
You must decide Fact / Dimension / Bridge / separate-fact roles.
Declared source grain and natural source identifiers are provided; modeling role, cardinality/filter direction and reconciliation are your work.
Do not join parts and labor facts raw and assume totals remain safe.
Protected review remains closed until your workbook/evidence is saved.
