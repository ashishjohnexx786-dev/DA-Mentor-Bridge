B03 GATE B - EDUCATION ENROLLMENT
Fresh full retest only when explicitly routed.
You must decide model roles, relationships, bridges, date roles and controls.
Attendance and assessments are separate lower-grain processes; do not assume a flat join is safe.
Protected review remains closed until your workbook/evidence is saved.
