B03 GATE C - ENERGY METER READINGS
Second fresh full retest only when explicitly routed.
You must decide model roles, shared dimensions, program bridge, date logic and target/readings grain treatment.
Protected review remains closed until your workbook/evidence is saved.
